<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\AdminChallenge;
use App\Models\AdminChallengeUserPlayedMatch;
use App\Models\AdminChallengeUserPlayMatch;


class AdminController extends Controller
{
    
    public function add_challenge(){


        return view('admin.add_challenge');

    }


    public function add_challenge_store(Request $req){

        $challenge = new AdminChallenge;
        $challenge->title = $req->title;
        $challenge->difficalty = $req->dif;
        $challenge->streak = $req->streak;
        $challenge->amount = $req->amount;
        $challenge->coin_sku = 'BITP';
        $challenge->save();

        return redirect('/admin-challenges');
    }



    public function admin_challenge(){
            
            $challenges = AdminChallenge::all();
    
            return view('admin.admin_challenge', compact('challenges'));
    }



}
