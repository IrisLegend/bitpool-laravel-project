<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\AdminChallenge;
use App\Models\AdminChallengeUserPlayedMatch;
use App\Models\AdminChallengeUserPlayMatch;
use Illuminate\Support\Facades\Cookie;

use Illuminate\Support\Facades\Http;


class FrontendController extends Controller
{


    
    



    public function dashboard(Request $req)
    {

        $uid = $req->uid;

        if($uid == null){
            $uid = Cookie::get('user_id');
           

            // if($uid == ""){
            //     header('Location: https://app.bitsport.gg/login?redirect=http://localhost:8000/?uid=1110');
            //     exit();
            // }
        }

        Cookie::queue('user_id', $uid, 60*24*30);
        $user = $this->getUserData();

        // dd($this->_user_id);

        $challenges = AdminChallenge::where('status', '1')->get();


        return view('dashboard', compact('challenges', 'user'));
    }


    public function quests(Request $request)
    {

        // $uid = $request->uid;
        $id = $request->id;

        $uid =  Cookie::get('user_id');
        // dd($uid);

        $challenge = AdminChallenge::where('id', $id)->first();

        $challenge_user_play_match = AdminChallengeUserPlayMatch::where('challenge_id',$challenge->id)->where('user_id', $uid)->orderBy('id', 'DESC')->first();

       if(!$challenge_user_play_match){

            $start = AdminChallengeUserPlayMatch::create([
                'user_id' => $uid,
                'challenge_id' => $challenge->id
            ]);

       }


       $cid = $challenge->id;

       $user = $this->getUserData();



       $msg = ($challenge_user_play_match->currant_match+1)." of ".$challenge->streak;



        return view('quests', compact('challenge', 'uid', 'cid', 'user', 'msg'));
    }





    public function getUserData(){


        // get user data from cookes
        $user_id = Cookie::get('user_id');

        $response = Http::post('https://app.bitsport.gg/api/bitpool/get-user', [
            'user_id' => $user_id
        ]);

        $response = $response->json();

       

        $user = $response['data'];


        if($user == null){

            $user = [
                'username' => "",
                'mbtc' => 0,
                'profile' => ""
            ];

            return $user;
        }




        // forget cookie
        Cookie::queue(Cookie::forget('user_name'));
        Cookie::queue(Cookie::forget('user_bitp'));
        Cookie::queue(Cookie::forget('user_img'));


        // set cookie
        Cookie::queue('user_name', $user['username'], 60*24*30);
        Cookie::queue('user_bitp', $user['mbtc'], 60*24*30);
        Cookie::queue('user_img', $user['profile'], 60*24*30);

        
        // dd($response);

        return $user;


    }



    public function getCurrantMatc($id){


        $uid =  Cookie::get('user_id');

        $challenge_user_play_match = AdminChallengeUserPlayMatch::where('challenge_id',$id)->where('user_id', $uid)->orderBy('id', 'DESC')->first();

        if($challenge_user_play_match){
            return $challenge_user_play_match->currant_match;
        }else{
                return 0;
            }

    }


    public function login(Request $req){
            
            $email = $req->email;
            $password = $req->password;
    

            $response = Http::post('https://app.bitsport.gg/api/bitpool/login', [
                'email' => $email,
                'password' => $password
            ]);


            $response_ = $response->json();

            if($response_['status'] == '0'){
                return back()->with('error', 'Invalid Email or Password');
            }

            // dd($response_);

            $user_id = $response_['uid'];
            
            Cookie::queue('user_id', $user_id, 60*24*30);
            $user = $this->getUserData();
    
    
            return back();
    }




    public function logout(){
        Cookie::queue(Cookie::forget('user_id'));
        Cookie::queue(Cookie::forget('user_name'));
        Cookie::queue(Cookie::forget('user_bitp'));
        Cookie::queue(Cookie::forget('user_img'));

        return redirect('/');
    }


    public function winner(Request $req){

        $req = $req->id;

        $challenge = AdminChallenge::where('id', $req)->first();


        $user = $this->getUserData();
        

        return view('winner', compact('challenge', 'user'));

    }




}
