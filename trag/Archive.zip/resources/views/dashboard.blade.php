
@extends("layout.main")


@section("content")
    

    <div class="col-md-12 mt-4">
        <div class="container">



            <div class="row mb-4">
                <div class="col-md-12">
                    <img src="/img/banner.png" alt="" class = "main-banner">
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class = "cus-card-titile-text">Quests</h4>
                                    <p class = "cus-card-titile-sub-text">Available on Bitpool web</p>
                                </div>
                            </div>
                </div>
            </div>


    


            @foreach($challenges as $c)

            <div class = "row mb-3">
                <div class = "col-md-12">
                    <div class="card bg-dark rounded">
                        <div class="card-body">
                            <div class="row">

                                <div class="col-md-2 adin-challenge-table-cell">
                                    BITPOOL
                                </div>

                                <div class="col-md-2 adin-challenge-table-cell mobile-padding-top">
                                    <p class = "table-cell-title">Amount</p>
                                    <p class = "table-cell-text">{{ $c->amount }} {{ $c->coin_sku }}</p>
                                </div>

                                <div class="col-md-2 adin-challenge-table-cell mobile-padding-top">
                                    <p class = "table-cell-title">Strack</p>
                                    <p class = "table-cell-text">{{ $c->streak }}</p>
                                </div>

                                <div class="col-md-2 adin-challenge-table-cell mobile-padding-top">
                                    <p class = "table-cell-title">Dificalty</p>
                                    <p class = "table-cell-text">
                                        @if($c->difficalty == 0)
                                            Easy
                                        @elseif($c->difficalty == '1')
                                            Medium
                                        @elseif($c->difficalty == '2')
                                            Hard
                                        @endif
                                    </p>
                                </div>

                                <div class="col-md-4 text-right adin-challenge-table-cell mobile-padding-top">

                                    <a class="btn btn-info accept-button" href = "/quests/{{$c->id}}">Accept ({{ \App\Http\Controllers\FrontendController::getCurrantMatc($c->id) }}/{{$c->streak}})</a>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @endforeach

    


       





        </div>


    @endsection
