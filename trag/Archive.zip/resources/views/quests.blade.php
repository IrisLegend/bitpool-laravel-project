
@extends("layout.main")


@section("content")



    <style>

@media only screen and (max-width: 768px) {

        .game-iframe {
            width: 96%;
            height: 96vh;
            margin-left: -2rem;
            position: fixed;
            top: 0;
            left: 0;
        }

        .top-nav{
            display: none;
        }


    }

    </style>

    

    <div class="col-md-12 mt-4">
        <div class="container">

            <!-- <div class="row">
                <div class="col-md-12">
                    <h6 class = "page-title">challenge {{ $msg }}</h6>
                </div>
            </div> -->


            <div class="row">
                <div class="col-md-12">

                    <iframe src="http://localhost:3000/?c={{$cid}}&u={{$uid}}" frameborder="0" class = "game-iframe"></iframe>


                </div>
            </div>





        </div>


    @endsection
