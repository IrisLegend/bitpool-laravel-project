<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BITPOOL</title>



    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>



    <link rel="stylesheet" href="/css/main.css">


</head>

<body>


    <!-- side manu  -->
    <div class="">
        <div class="row">
            <div style="width:10rem" class="side-nav">
                <div class="row">
                    <div class="col-md-12">
                        <!-- <img src="https://app.bitsport.gg/img/logo.png" alt="" class="img-fluid side-nav-logo"> -->
                        <img src="/img/logo.svg" alt="" class="img-fluid side-nav-logo" onClick = "window.location.href = '/'">
                    </div>
                </div>
                <div class="row justify-content-center">


                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/featured.svg">
                            <br />
                            <span class="side-nav-item-text">Featured</span>
                        </a>
                    </div>



                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/nft.svg">
                            <br />
                            <span class="side-nav-item-text">NFT</span>
                        </a>
                    </div>



                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/leadership.svg">
                            <br />
                            <span class="side-nav-item-text">Leadership</span>
                        </a>
                    </div>

                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/leadership.svg">
                            <br />
                            <span class="side-nav-item-text">news & events</span>
                        </a>
                    </div>

                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/leadership.svg">
                            <br />
                            <span class="side-nav-item-text">tutorial</span>
                        </a>
                    </div>

                    <div class="side-nav-item">
                        <a href="/" class="side-nav-link">
                            <img src="/img/leadership.svg">
                            <br />
                            <span class="side-nav-item-text">dapp</span>
                        </a>
                    </div>


                </div>
            </div>

            <div style="width: calc(100% - 10rem)" class = "content-div">

                <div class="row">
                    <div class="col-md-12">
                        <div class="top-nav">

                            <div class="row d-flex justify-content-between align-items-center">

                                <div class="col-md-4 col-6">
                                    <h1 class = "site-title" onClick = "window.location.href = '/'">BITPOOL</h1>

                                </div>

                                <div class="col-md-8 col-6  text-right top-nav-right">
                                    
                                    <div class = "top-nav-btp-box" onClick = "document.location.href = 'https://app.bitsport.gg/wallet'">
                                        <img src = "/img/bitp.svg" style="margin-right:10px">
                                        <span class = "top-nav-btp-amount"> <?php echo e($user['mbtc']); ?> </span>
                                        <span class = "top-nav-btp-text">BITP</span>
                                    </div>

                                    <div class = "mobile-hide">
                                        <img class="rounded-circle shadow-4-strong top-nav-user" alt="avatar2" src="/img/user.svg" />
                                    </div>



                                </div>

                                

                            </div>


                        </div>
                    </div>

                    <div class="main-contant container">
        
                        <?php echo $__env->yieldContent('content'); ?>

                        <br/>
                        <br/>
                    </div>

                </div>



                
                <?php if(Cookie::get('user_id') == ''): ?>
                 <!-- Login popup modal -->
                    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true" style = "display:block; opacity:1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content bg-dark rounded" >
                                <div class="modal-body text-center">
                                    <h3 class = "login-title">BITPOOL</h3>
                                    <h6 class="mb-3">Login to your Bitsport account</h6>
                                    <form action = "/login" method = "post">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3 text-left">
                                            <label for="email" class="form-label">Email address</label>
                                            <input type="email" class="form-control" name="email" aria-describedby="emailHelp" required>
                                        </div>
                                        <div class="mb-3 text-left">
                                            <label for="password" class="form-label">Password</label>
                                            <input type="password" class="form-control" name="password" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary login-btn">Login</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>





    








            </div>

        </div>







</body>

</html><?php /**PATH /Users/bathiyachathuranga/Desktop/bitpool laravel backend/resources/views/layout/main.blade.php ENDPATH**/ ?>