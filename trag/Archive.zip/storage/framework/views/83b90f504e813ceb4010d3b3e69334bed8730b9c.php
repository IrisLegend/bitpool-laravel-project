<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">


</head>
<body>



    <div class="container">

        <div class="row mt-4">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">

                        <div>
                            <h4>Admin Challenge</h4>
                        </div>

                        <div>
                            <a href="/add-challenge" class="btn btn-primary">Add Challenge</a>
                        </div>

                    </div>

                    <hr>



                    <table class = "table table-responcive">
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Difficalty</th>
                            <th>Streak</th>
                            <th>Amount</th>
                            <th>Coin Sku</th>
                            <th>Status</th>
                            <th>Created At</th>
                        </tr>

                        <?php $__currentLoopData = $challenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($challenge->id); ?></td>
                                <td><?php echo e($challenge->title); ?></td>
                                <td><?php echo e($challenge->difficalty); ?></td>
                                <td><?php echo e($challenge->streak); ?></td>
                                <td><?php echo e($challenge->amount); ?></td>
                                <td><?php echo e($challenge->coin_sku); ?></td>
                                <td>
                                    <?php if($challenge->status == 1): ?>
                                        Active
                                    <?php else: ?>
                                        Completed
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($challenge->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>



                </div>
            </div>
        </div>
    </div>








    
</body>
</html><?php /**PATH /Users/bathiyachathuranga/Desktop/bitpool laravel backend/resources/views/admin/admin_challenge.blade.php ENDPATH**/ ?>