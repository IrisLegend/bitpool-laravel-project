<?php $__env->startSection("content"); ?>



    <style>

        .game-iframe {
            width: 96%;
            height: 96vh;
            margin-left: -2rem;
            position: fixed;
            top: 0;
            left: 0;
        }

        .top-nav{
            display: none;
        }




    </style>

    

    <div class="col-md-12 mt-4">
        <div class="container">

            <!-- <div class="row">
                <div class="col-md-12">
                    <h6 class = "page-title">challenge <?php echo e($msg); ?></h6>
                </div>
            </div> -->


            <div class="row">
                <div class="col-md-12">

                    <iframe src="http://localhost:3000/?c=<?php echo e($cid); ?>&u=<?php echo e($uid); ?>" frameborder="0" class = "game-iframe"></iframe>


                </div>
            </div>





        </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bathiyachathuranga/Desktop/bitpool laravel backend/resources/views/quests.blade.php ENDPATH**/ ?>